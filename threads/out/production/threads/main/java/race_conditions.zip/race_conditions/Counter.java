package main.java.race_conditions;

public class Counter {
    public static long count;
}
