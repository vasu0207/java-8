package main.java.race_conditions;

public class UpdateCounter extends Thread {

    public void increaseCounter(){
        Counter.count++;
        System.out.println("Thread Name : " + Thread.currentThread().getName()+" { count : " + Counter.count+"}");
    }

    @Override
    public void run(){
        increaseCounter();
        increaseCounter();
        increaseCounter();
    }
}
